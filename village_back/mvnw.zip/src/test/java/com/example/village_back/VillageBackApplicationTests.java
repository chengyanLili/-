package com.example.village_back;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VillageBackApplicationTests {

    @Test
    void contextLoads() {
    }

}
