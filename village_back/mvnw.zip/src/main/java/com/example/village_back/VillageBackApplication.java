package com.example.village_back;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VillageBackApplication {

    public static void main(String[] args) {
        SpringApplication.run(VillageBackApplication.class, args);
    }

}
